mapbox-studio-default-style + nutiteq features
===========================
Style for with continous zoom for Nutiteq vt-s
